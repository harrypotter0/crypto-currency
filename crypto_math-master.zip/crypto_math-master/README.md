# crypto_math
This is the code for "Crypto Math" by Siraj Raval on Youtube 

## Overview

This is the code for [this](https://youtu.be/tK3wuQN9MHE) video on Youtube by Siraj Raval. Use [Jupyter notebook](http://jupyter.org/) to open this locally. 

## Cryptpad demo


[Here](https://github.com/xwiki-labs/cryptpad) is a link to cryptpad, the project i demo'd in the video. 


